@extends('layouts.main')

@section('content')
<div class="row">
    <div class="col">
        <h1>Índice de heroes</h1>
    </div>
</div>
<div class="row">
    <div class="col">
        <a class="btn btn-primary" href="{{ route('heroes.create') }}" role="button">Agregar un heroe</a>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table">
            <theader>
                <th>Nombre</th>
                <th>Juego</th>
                <th>Consola</th>
            </theader>
            <tbody>
                @foreach($heroes as $heroe)
                    <tr>
                        <td>
                            {{ $heroe->nombre }}
                        </td>
                        <td>
                            {{ $heroe->juego }}
                        </td>
                        <td>
                            {{ $heroe->consola }}
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection