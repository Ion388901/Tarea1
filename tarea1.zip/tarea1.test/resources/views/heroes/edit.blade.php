@extends('layout')

@section('content')
<style>
    .uper{
        margin-top: 40px;
    }
</style>
<div class="card uper">
    <div class="card-header">
        Edit Share
    </div>
    <div class="card-body">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div><br />
        @endif
            <form method="post" action="{{ route('heroes.update', $heroe->id)}}">
                @method('PATCH')
                @csrf
                <div class="form-group">
                    <label for="nombre">Heroe Nombre:</label>
                    <input type="text" class="form-control" nombre="nombre" value={{ $heroe->nombre }}/>
                    </div>
                <div class="form-group">
                    <label for="edad">Heroe Edad</label>
                    <input type="float" class="form-control" edad="edad" value={{ $heroe->edad }}/>
                    </div>
                <div class="form-group">
                    <label for="arma">Heroe Arma</label>
                    <input type="text" class="form-control" arma="arma" value={{ $heroe->arma }}/>
                    </div>
                <div class="form-group">
                    <label for="juego">Heroe Juego</label>
                    <input type="text" class="form-control" juego="juego" value={{ $heroe->juego }}/>
                    </div>
                <div class="form-group">
                    <label for="consola">Heroe Consola</label>
                    <input type="text" class="form-control" consola="consola" value={{ $heroe->consola }}/>
                    </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
@endsection
                    