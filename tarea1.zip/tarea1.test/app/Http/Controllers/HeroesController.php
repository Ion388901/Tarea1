<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\Models\Heroe;

class HeroesController extends BaseController{
    public function index(Request $req){
        $heroes = Heroe::all();
        $data = [];
        $data['heroes'] = $heroes;      
        return view('heroes.index', $data);
    }

    public function create(Request $req){
        return view('heroes.create');
    }

    public function store(Request $req){
        $heroeInput = $req->input('heroe');
        $heroe = Heroe::create($heroeInput);
        return redirect()->route('heroes.index');
    }

    public function edit($id){
        $heroe = Heroe::find($id);
        return view('heroes.edit', compact('heroe'));
    }

    public function update(Request $req, $id){
        $heroe->validate([
            'nombre'=>'requerido',
            'edad'=>'requerido|entero',
            'arma'=>'requerido',
            'juego'=>'requerido',
            'consola'=>'requerido'
        ]);

        $heroe = Heroe::find($id);
        $heroe->nombre = $request->get('nombre');
        $heroe->edad = $request->get('edad');
        $heroe->arma = $request->get('arma');
        $heroe->juego = $request->get('juego');
        $heroe->consola = $request->get('consola');
        $heroe->save();

        return redirect('/heroes')->with('Función realizada', 'Se actualizo la información');
    }

    public function eliminate($id){
        $heroe = Heroe::find($id);
        $heroe->delete();
        return redirect('/heroes')->with('Función realizada', 'Se borro el elemento indicado');
    }

}
