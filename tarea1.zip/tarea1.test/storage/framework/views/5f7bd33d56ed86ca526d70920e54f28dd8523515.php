<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">
        <h1>Índice de heroes</h1>
    </div>
</div>
<div class="row">
    <div class="col">
        <a class="btn btn-primary" href="<?php echo e(route('heroes.create')); ?>" role="button">Agregar un heroe</a>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table">
            <theader>
                <th>Nombre</th>
                <th>Juego</th>
                <th>Consola</th>
            </theader>
            <tbody>
                <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($heroe->nombre); ?>

                        </td>
                        <td>
                            <?php echo e($heroe->juego); ?>

                        </td>
                        <td>
                            <?php echo e($heroe->consola); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>