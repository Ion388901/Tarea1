<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">
        <h1>Crear un nuevo heroe</h1>
    </div>
</div>
<form action="<?php echo e(route('heroes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col">
            <div class="form-group">
                <label>Nombre</label>
                <input type="text" class="form-control" name="heroe[nombre]">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="form-group">
                <label>Edad</label>
                <input type="number" class="form-control" name="heroe[edad]">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="form-group">
                <label>Arma</label>
                <input type="text" class="form-control" name="heroe[arma]">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="form-group">
                <label>Juego</label>
                <input type="text" class="form-control" name="heroe[juego]">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="form-group">
                <label>Consola</label>
                <input type="text" class="form-control" name="heroe[consola]">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>